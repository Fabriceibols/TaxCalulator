﻿using PayspaceAssessmentKibuluku.Models.DbModel;
using PayspaceAssessmentKibuluku.Repository.Sql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PayspaceAssessmentKibuluku.Service.TaxCalculator
{
    public class ProgressiveTaxCalculator : ITaxCalculator
    {
        private List<Rate> _rate;

        public ProgressiveTaxCalculator(List<Rate> rate)
        {
            _rate = rate;
        }
        public double CalcualtionTax(double annualIncome)
        {
            var percentage = _rate.Find(x => x.FromRate <= (decimal)annualIncome
            && x.ToRate >= (decimal)annualIncome)
            .Rates;

            var tax = ((decimal)annualIncome * percentage) / 100;

            return (double)tax;
        }
    }
}
