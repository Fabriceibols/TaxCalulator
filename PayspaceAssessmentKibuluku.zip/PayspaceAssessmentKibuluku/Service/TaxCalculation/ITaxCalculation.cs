﻿using PayspaceAssessmentKibuluku.Models.ViewModels;
using PayspaceAssessmentKibuluku.Service.TaxCalculation.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PayspaceAssessmentKibuluku.Service.TaxCalculation
{
    public interface ITaxCalculation
    {
        CalculationResponse CalculationIncomeTax(TaxViewModel taxViewModel);
    }
}
