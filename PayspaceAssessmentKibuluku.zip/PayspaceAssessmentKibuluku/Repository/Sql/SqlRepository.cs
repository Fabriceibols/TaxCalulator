﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PayspaceAssessmentKibuluku.Models.DbModel;

namespace PayspaceAssessmentKibuluku.Repository.Sql
{
    public class SqlRepository : ISqlRepository
    {
        private readonly TaxDbContext _taxDbContext;

        public SqlRepository()
        {
            _taxDbContext = new TaxDbContext();
        }

        public CalculationType GetCalculationType(int id)
        {
            return _taxDbContext.CalculationType.Where(x => x.TaxTypeId == id).SingleOrDefault();
        }

        public PostalCode GetPostalCode(string postalCode)
        {
            return _taxDbContext.PostalCode.SingleOrDefault(x => x.PostalCodes == postalCode);
        }

        public IReadOnlyCollection<PostalCode> GetPostalCodes()
        {
            return _taxDbContext.PostalCode.ToList();
        }

        public IReadOnlyCollection<Rate> GetRates()
        {
            return _taxDbContext.Rate.ToList();
        }

        public IReadOnlyCollection<TaxCalculation> GetTaxCalculations()
        {
            return _taxDbContext.TaxCalculation.ToList();
        }

        public bool Save(TaxCalculation taxCalculation)
        {
            _taxDbContext.TaxCalculation.Add(taxCalculation);
            var result =_taxDbContext.SaveChanges();

            if (result > double.Epsilon)
                return true;

            return false;
        }
    }
}
