﻿using Microsoft.EntityFrameworkCore;
using PayspaceAssessmentKibuluku.Models.DbModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PayspaceAssessmentKibuluku.Repository.Sql
{
    public class TaxDbContext : DbContext
    {
        public TaxDbContext()
        {

        }

        public TaxDbContext(DbContextOptions<TaxDbContext> options) : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(@"Server=.hp-probook\sqlexpress;Database=TaxCalculator;Trusted_Connection=True;MultipleActiveResultSets=true");
            }
        }

        public DbSet<Rate> Rate { get; set; }
        public DbSet<CalculationType> CalculationType { get; set; }
        public DbSet<PostalCode> PostalCode { get; set; }
        public DbSet<TaxCalculation> TaxCalculation { get; set; }
    }
}
