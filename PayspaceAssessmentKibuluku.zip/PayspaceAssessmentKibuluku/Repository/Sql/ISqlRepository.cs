﻿using PayspaceAssessmentKibuluku.Models.DbModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PayspaceAssessmentKibuluku.Repository.Sql
{
    public interface ISqlRepository
    {
        IReadOnlyCollection<PostalCode> GetPostalCodes();
        IReadOnlyCollection<Rate> GetRates();
        IReadOnlyCollection<TaxCalculation> GetTaxCalculations();

        CalculationType GetCalculationType(int id);
        PostalCode GetPostalCode(string postalCode);
        bool Save(TaxCalculation taxCalculation);
    }
}
