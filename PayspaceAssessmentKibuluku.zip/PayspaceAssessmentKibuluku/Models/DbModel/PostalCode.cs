﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace PayspaceAssessmentKibuluku.Models.DbModel
{
    public class PostalCode
    {
        [Key]
        public int PostalCodeId { get; set; }
        public string PostalCodes { get; set; }
        [ForeignKey("TaxTypeId")]
        public int TaxTypeId { get; set; }
        public CalculationType CalculationType { get; set; }
    }
}
