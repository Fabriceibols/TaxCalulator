﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PayspaceAssessmentKibuluku.Models.DbModel
{
    public class Rate
    {
        [Key]
        public int RateId { get; set; }
        public decimal Rates { get; set; }
        public decimal FromRate { get; set; }
        public decimal ToRate { get; set; }
    }
}
