using System;
using System.ComponentModel.DataAnnotations;

namespace PayspaceAssessment.Models.ViewModels
{
    public class TaxViewModel
    {
        [Required]
        public string Name { get; set; }
        [Required]
        [Display(Name = "annual income")]
        public double AnnualIncome { get; set; }
        [Display(Name = "postal code")]
        public string PostalCode { get; set; }
    }
}
